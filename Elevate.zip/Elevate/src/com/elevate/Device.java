package com.elevate;  

import java.io.Serializable;  
import java.time.LocalTime;  
import java.time.LocalDateTime;

import javax.xml.bind.annotation.XmlElement; 
import javax.xml.bind.annotation.XmlRootElement; 
@XmlRootElement(name = "device") 

public class Device implements Serializable {
	
   private static final long serialVersionUID = 1L; 
   private int id; 
   private String severity;
   private String type;
   private int count;
   private String alerttime;

   public Device(){} 
    
   public Device(int id, String name, String type, int count, String alerttime){  
      this.id = id; 
      this.severity = name; 
      this.type = type;
      this.count = count;
      this.alerttime = alerttime;
   }  
   public int getId() { 
      return id; 
   }  
   public void setId(int id) { 
      this.id = id; 
   } 
   public String getSeverity() { 
      return severity; 
   } 
   @XmlElement
   public void setSeverity(String severity) { 
      this.severity = severity; 
   } 
   public String getType() { 
      return type; 
   } 
   @XmlElement 
   public void setType(String type) { 
      this.type = type; 
   }   
   
   public int getCount() { 
	      return count; 
	   }  
	   @XmlElement 
	   public void setCount(int count) { 
	      this.count = count; 
	   } 
	   
	   public String getAlertTime() { 
		      return this.alerttime; 
	  }  
	   @XmlElement 
	   public void setAlertTime(String alerttime) { 
	      this.alerttime = alerttime; 
	   } 
} 