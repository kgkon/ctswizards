package com.elevate;  

import java.util.List; 
import javax.ws.rs.GET; 
import javax.ws.rs.Path; 
import javax.ws.rs.Produces; 
import javax.ws.rs.core.MediaType;  
@Path("/E911Service") 

public class E911Service {  
   E911Dao e911Dao = new E911Dao();  
   @GET 
   @Path("/e911") 
   @Produces(MediaType.APPLICATION_XML) 
   public List<E911> getE911s(){ 
      return e911Dao.getAllE911s(); 
   }  
}