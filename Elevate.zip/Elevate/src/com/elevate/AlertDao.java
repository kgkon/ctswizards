package com.elevate;  

import java.io.File; 
import java.io.FileInputStream; 
import java.io.FileNotFoundException;  
import java.io.FileOutputStream; 
import java.io.IOException; 
import java.io.ObjectInputStream; 
import java.io.ObjectOutputStream; 
import java.util.ArrayList; 
import java.util.List;
import java.time.format.DateTimeFormatter;
import java.time.LocalDateTime;

public class AlertDao { 
   public List<Alert> getAllAlerts(){ 
      
      List<Alert> alertList = null;
      Alert alert;
      try { 
         File file = new File("Alerts.dat"); 
         if (!file.exists()) { 
            alertList = new ArrayList<Alert>();
            for (int i = 0; i < 10; i++)
            {
                DateTimeFormatter dtf = DateTimeFormatter.ofPattern("yyyy/MM/dd HH:mm:ss"); 
                LocalDateTime now = LocalDateTime.now();
                int count = i + 1;
                alert = new Alert(count, "high", "gunshot", count, now + "."); 
                alertList.add(alert);
            }
            saveAlertList(alertList); 
         } 
         else{ 
            FileInputStream fis = new FileInputStream(file); 
            ObjectInputStream ois = new ObjectInputStream(fis); 
            alertList = (List<Alert>) ois.readObject(); 
            ois.close(); 
         } 
      } catch (IOException e) { 
         e.printStackTrace(); 
      } catch (ClassNotFoundException e) { 
         e.printStackTrace(); 
      }   
      return alertList; 
   } 
   private void saveAlertList(List<Alert> alertList){ 
      try { 
         File file = new File("Alerts.dat"); 
         FileOutputStream fos;  
         fos = new FileOutputStream(file); 
         ObjectOutputStream oos = new ObjectOutputStream(fos); 
         oos.writeObject(alertList); 
         oos.close(); 
      } catch (FileNotFoundException e) { 
         e.printStackTrace(); 
      } catch (IOException e) { 
         e.printStackTrace(); 
      } 
   }    
}