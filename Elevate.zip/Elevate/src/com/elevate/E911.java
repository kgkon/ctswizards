package com.elevate;  

import java.io.Serializable;  
import java.time.LocalTime;  
import java.time.LocalDateTime;

import javax.xml.bind.annotation.XmlElement; 
import javax.xml.bind.annotation.XmlRootElement; 
@XmlRootElement(name = "e911") 

public class E911 implements Serializable {
	
   private static final long serialVersionUID = 1L; 
   private int id; 
   private String severity;
   private String type;
   private int count;
   private String alerttime;
   private String customerNum;
   private String location;
   
   public E911(){} 
    
   public E911(int id, String name, String type, int count, String alerttime, String, customerNum, String location){  
      this.id = id; 
      this.severity = name; 
      this.type = type;
      this.count = count;
      this.alerttime = alerttime;
      this.customerNum = customerNum;
      this.location = location;
   }  
   public int getId() { 
      return id; 
   }  
   public void setId(int id) { 
      this.id = id; 
   } 
   public String getSeverity() { 
      return severity; 
   } 
   @XmlElement
   public void setSeverity(String severity) { 
      this.severity = severity; 
   } 
   public String getType() { 
      return type; 
   } 
   @XmlElement 
   public void setType(String type) { 
      this.type = type; 
   }   
   
   public int getCount() { 
	      return count; 
	   }  
	   @XmlElement 
	   public void setCount(int count) { 
	      this.count = count; 
	   } 
	   
	   public String getAlertTime() { 
		      return this.alerttime; 
	  }  
	   @XmlElement 
	   public void setAlertTime(String alerttime) { 
	      this.alerttime = alerttime; 
	   } 
	   
	   public String getCustomerNum() { 
		      return customerNum; 
		   } 
		   @XmlElement 
		   public void setCustomerNum(String customerNum) { 
		      this.customerNum = customerNum; 
		   }   
		   
		   public String getLocation() { 
			      return location; 
			   } 
			   @XmlElement 
			   public void setLocation(String location) { 
			      this.location = location; 
			   }   
		   
		   
} 

