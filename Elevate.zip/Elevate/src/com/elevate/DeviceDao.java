package com.elevate;  

import java.io.File; 
import java.io.FileInputStream; 
import java.io.FileNotFoundException;  
import java.io.FileOutputStream; 
import java.io.IOException; 
import java.io.ObjectInputStream; 
import java.io.ObjectOutputStream; 
import java.util.ArrayList; 
import java.util.List;
import java.time.format.DateTimeFormatter;
import java.time.LocalDateTime;

public class DeviceDao { 
   public List<Device> getAllDevices(){ 
      
      List<Device> deviceList = null;
      Device device;
      try { 
         File file = new File("Devices.dat"); 
         if (!file.exists()) { 
            deviceList = new ArrayList<Device>();
            for (int i = 0; i < 10; i++)
            {
                DateTimeFormatter dtf = DateTimeFormatter.ofPattern("yyyy/MM/dd HH:mm:ss"); 
                LocalDateTime now = LocalDateTime.now();
                int count = i + 1;
                device = new Device(count, "high", "gunshot", count, now + "."); 
                deviceList.add(device);
            }
            saveDeviceList(deviceList); 
         } 
         else{ 
            FileInputStream fis = new FileInputStream(file); 
            ObjectInputStream ois = new ObjectInputStream(fis); 
            deviceList = (List<Device>) ois.readObject(); 
            ois.close(); 
         } 
      } catch (IOException e) { 
         e.printStackTrace(); 
      } catch (ClassNotFoundException e) { 
         e.printStackTrace(); 
      }   
      return deviceList; 
   } 
   private void saveDeviceList(List<Device> deviceList){ 
      try { 
         File file = new File("Devices.dat"); 
         FileOutputStream fos;  
         fos = new FileOutputStream(file); 
         ObjectOutputStream oos = new ObjectOutputStream(fos); 
         oos.writeObject(deviceList); 
         oos.close(); 
      } catch (FileNotFoundException e) { 
         e.printStackTrace(); 
      } catch (IOException e) { 
         e.printStackTrace(); 
      } 
   }    
}