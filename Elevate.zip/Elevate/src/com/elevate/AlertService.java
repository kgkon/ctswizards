package com.elevate;  

import java.util.List; 
import javax.ws.rs.GET; 
import javax.ws.rs.Path; 
import javax.ws.rs.Produces; 
import javax.ws.rs.core.MediaType;  
@Path("/AlertService") 

public class AlertService {  
   AlertDao alertDao = new AlertDao();  
   @GET 
   @Path("/alerts") 
   @Produces(MediaType.APPLICATION_XML) 
   public List<Alert> getAlerts(){ 
      return alertDao.getAllAlerts(); 
   }  
}