package com.elevate;  

import java.io.File; 
import java.io.FileInputStream; 
import java.io.FileNotFoundException;  
import java.io.FileOutputStream; 
import java.io.IOException; 
import java.io.ObjectInputStream; 
import java.io.ObjectOutputStream; 
import java.util.ArrayList; 
import java.util.List;
import java.time.format.DateTimeFormatter;
import java.time.LocalDateTime;

public class E911Dao { 
   public List<E911> getAllE911s(){ 
      
      List<E911> e911List = null;
      E911 e911;
      try { 
         File file = new File("E911s.dat"); 
         if (!file.exists()) { 
            e911List = new ArrayList<E911>();
            for (int i = 0; i < 10; i++)
            {
                DateTimeFormatter dtf = DateTimeFormatter.ofPattern("yyyy/MM/dd HH:mm:ss"); 
                LocalDateTime now = LocalDateTime.now();
                int count = i + 1;
                e911 = new E911(count, "high", "gunshot", count, now + ".", "CustomerNum_" + count, "Location_" + count); 
                e911List.add(e911);
            }
            saveE911List(e911List); 
         } 
         else{ 
            FileInputStream fis = new FileInputStream(file); 
            ObjectInputStream ois = new ObjectInputStream(fis); 
            e911List = (List<E911>) ois.readObject(); 
            ois.close(); 
         } 
      } catch (IOException e) { 
         e.printStackTrace(); 
      } catch (ClassNotFoundException e) { 
         e.printStackTrace(); 
      }   
      return e911List; 
   } 
   private void saveE911List(List<E911> e911List){ 
      try { 
         File file = new File("E911.dat"); 
         FileOutputStream fos;  
         fos = new FileOutputStream(file); 
         ObjectOutputStream oos = new ObjectOutputStream(fos); 
         oos.writeObject(e911List); 
         oos.close(); 
      } catch (FileNotFoundException e) { 
         e.printStackTrace(); 
      } catch (IOException e) { 
         e.printStackTrace(); 
      } 
   }    
}