package com.elevate;  

import java.util.List; 
import javax.ws.rs.GET; 
import javax.ws.rs.Path; 
import javax.ws.rs.Produces; 
import javax.ws.rs.core.MediaType;  
@Path("/DeviceService") 

public class DeviceService {  
   DeviceDao deviceDao = new DeviceDao();  
   @GET 
   @Path("/devices") 
   @Produces(MediaType.APPLICATION_XML) 
   public List<Device> getDevices(){ 
      return deviceDao.getAllDevices(); 
   }  
}